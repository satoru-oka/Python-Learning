# import * を使う為には以下の記述をする
__all__ = ['animal']