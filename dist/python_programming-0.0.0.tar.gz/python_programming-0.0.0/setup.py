from setuptools import setup

setup(
    name='python_programming',
    version='',
    packages=['test_package', 'test_package.talk', 'test_package.tools'],
    url='http://localhost',
    license='Free',
    author='satoru',
    author_email='fuck you',
    description=''
)
